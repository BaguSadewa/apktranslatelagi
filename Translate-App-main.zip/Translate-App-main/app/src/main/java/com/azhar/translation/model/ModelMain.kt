package com.azhar.translation.model

/**
 * Created by Azhar Rivaldi on 25-02-2021
 */

class ModelMain {
    var strTranslation: String = ""
}