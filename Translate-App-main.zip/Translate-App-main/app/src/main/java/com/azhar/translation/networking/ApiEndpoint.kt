package com.azhar.translation.networking

/**
 * Created by Azhar Rivaldi on 24-02-2021
 */

object ApiEndpoint {
    var BASEURL = "https://api-translate.azharimm.tk/translate?engine=google&text={text}&to={to}"
}